from vectorizer import vectorize_questions
import numpy as np
import faiss  # 确保导入 faiss

def retrieve_documents(user_query, index_questions, index_documents, questions, question_to_doc_mapping, documents, vectorizer_params):
    """
    检索用户查询相关的问题和文档。

    参数:
        user_query (str): 用户输入的问题。
        index_questions (faiss.Index): 问题的 FAISS 索引。
        index_documents (faiss.Index): 文档的 FAISS 索引。
        questions (list of str): 所有生成的问题。
        question_to_doc_mapping (dict): 问题到文档 ID 的映射。
        documents (list of dict): 所有文档的列表。

    返回:
        dict: 包含检索到的相关文档块列表。
    """
    try:
        # 向量化用户查询
        # 移除显式传递的 model_type 参数，仅通过 **vectorizer_params 传递
        query_vector = vectorize_questions([user_query], **vectorizer_params)
        
        # 确保向量维度匹配
        expected_dim = index_questions.d  # 获取 FAISS 索引的维度
        if query_vector.shape[1] != expected_dim:
            raise AssertionError(f"查询向量的维度 {query_vector.shape[1]} 不匹配 FAISS 索引的维度 {expected_dim}")
        
        k = 3  # 设置检索的 top 数量

        print(f"长度 - 问题列表: {len(questions)}, 文档列表: {len(documents)}")
        print(f"查询向量维度: {query_vector.shape}")

        # 在问题索引中搜索最相似的 k 个向量
        D_q, I_q = index_questions.search(query_vector, k)
        print(f"问题搜索得到的索引: {I_q[0]}")
        print(f"问题搜索得到的距离: {D_q[0]}")

        # 在文档索引中搜索最相似的 k 个向量
        D_d, I_d = index_documents.search(query_vector, k)
        print(f"文档搜索得到的索引: {I_d[0]}")
        print(f"文档搜索得到的距离: {D_d[0]}")

        results = {
            "related_questions": [],
            "related_documents": []
        }

        # 处理问题索引的结果
        for idx, distance in zip(I_q[0], D_q[0]):
            if idx >= 0 and idx < len(questions):
                question = questions[idx]
                doc_id = question_to_doc_mapping.get(question)
                if doc_id and not doc_id.startswith("processed_"):  # 排除处理文件
                    results["related_questions"].append({
                        "question": question,
                        "doc_id": doc_id,
                        "distance": float(distance)  # 确保距离是 Python 原生类型
                    })
                    print(f"找到相关问题: {question} (距离: {distance})")
            else:
                print(f"问题索引超出范围: {idx}")

        # 处理文档索引的结果
        for idx, distance in zip(I_d[0], D_d[0]):
            if idx >= 0 and idx < len(documents):
                doc = documents[idx]
                if not doc["id"].startswith("processed_"):  # 排除处理文件
                    results["related_documents"].append({
                        "doc_id": doc["id"],
                        "text": doc["text"],
                        "distance": float(distance)  # 确保距离是 Python 原生类型
                    })
                    print(f"找到相关文档: {doc['id']} (距离: {distance})")
            else:
                print(f"文档索引超出范围: {idx}")

        # 按距离排序
        results["related_questions"].sort(key=lambda x: x["distance"])
        results["related_documents"].sort(key=lambda x: x["distance"])

        # 移除重复的文档 ID
        unique_doc_ids = set()
        unique_related_documents = []
        for doc in results["related_documents"]:
            if doc["doc_id"] not in unique_doc_ids:
                unique_related_documents.append(doc)
                unique_doc_ids.add(doc["doc_id"])
                print(f"添加唯一文档: {doc['doc_id']}")

        results["related_documents"] = unique_related_documents

        print(f"检索到的相关问题数量: {len(results['related_questions'])}")
        print(f"检索到的相关文档数量: {len(results['related_documents'])}")

        # 添加额外的调试信息
        if not results["related_questions"]:
            print("警告: 未找到相关问题")
        if not results["related_documents"]:
            print("警告: 未找到相关文档")

        return results

    except AssertionError as ae:
        print(f"AssertionError: {ae}")
        raise
    except Exception as e:
        print(f"检索过程中发生错误: {str(e)}")
        raise
